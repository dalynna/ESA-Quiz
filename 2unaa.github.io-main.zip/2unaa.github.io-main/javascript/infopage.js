var dog = document.getElementById("box-dog");
document.getElementById("dog-radio").addEventListener("click",function(){
    dog.style.display = "block";
    cat.style.display = "none";
    rabbit.style.display = "none";
    parrot.style.display = "none";
    gp.style.display = "none";
})

var cat = document.getElementById("box-cat");
document.getElementById("cat-radio").addEventListener("click",function(){
    cat.style.display = "block";
    dog.style.display = "none";
    rabbit.style.display = "none";
    parrot.style.display = "none";
    gp.style.display = "none";
})

var rabbit = document.getElementById("box-rabbit");
document.getElementById("rabbit-radio").addEventListener("click",function(){
    rabbit.style.display = "block";
    dog.style.display = "none";
    cat.style.display = "none";
    parrot.style.display = "none";
    gp.style.display = "none";
})

var parrot = document.getElementById("box-parrot");
document.getElementById("parrot-radio").addEventListener("click",function(){
    parrot.style.display = "block";
    dog.style.display = "none";
    cat.style.display = "none";
    rabbit.style.display = "none";
    gp.style.display = "none";
})

var gp = document.getElementById("box-gp");
document.getElementById("gp-radio").addEventListener("click",function(){
    gp.style.display = "block";
    dog.style.display = "none";
    cat.style.display = "none";
    rabbit.style.display = "none";
    parrot.style.display = "none";
})


